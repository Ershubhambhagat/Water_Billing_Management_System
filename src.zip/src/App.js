import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import EntryPoint from './Components/EntrytPoint.js/EntryPoint'
import Login1 from './Components/Login/Login1';
import Login2 from './Components/Login/Login2';
import Form from './Components/Signup/Form';
import UserDashboard from './Components/UserDashboard/UserDashboard'
import Contact_us from './Components/UserDashboard/Contact_us';










function App() {
  return (
    <div>
      <Router>
      <Routes>
      <Route exact path='/' element={<EntryPoint/>}/>

      <Route path='/Login/Login1' element={<Login1/>}/>
         <Route path='/Login/Login2' element={<Login2/>}/> 
         
         <Route path='/Signup/Form' element={<Form/>}/>
         
         <Route path='/UserDashboard/Contact_us' element={<Contact_us/>}/>
        


         <Route path='/UserDashboard/UserDashboard' element={<UserDashboard/>}/> 



         <Route exact path='/' element={<EntryPoint/>}/>
          
        
          


      </Routes>
      </Router>

    </div>
  );
}

export default App;
