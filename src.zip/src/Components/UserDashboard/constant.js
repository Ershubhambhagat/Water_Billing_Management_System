
export const imageCollection = [
    {
    link: "/Assets/Images/1.jpg",
    },
    {
    link: "/Assets/Images/2.jpg",
    },
    {
    link: "/Assets/Images/4.jpg",
    },
    ];export const imageCollection1 = [
    {
    link: "/test.svg",
    },
    {
    link: "/Assets/Images/Adobe.jpg",
    },
    {
    link: "/Assets/Images/Aws.png",
    },
    {
    link: "/Assets/Images/CyberPark.png",
    },
    {
    link: "/Assets/Images/Microsoft.png",
    }, {
    link: "/Assets/Images/micro-focus.jpg",
    },
    ];
    
    