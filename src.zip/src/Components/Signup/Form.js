import style from './Form.module.css'
import FormInput from "./FormInput";
import React, {useState} from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Form = () => {

const navigate = useNavigate();
  
  const [data, setdata] = useState({ FullName: '', mobile_no: '', Email: '', username: '', password: '', confirm_password: '' })  
  const apiUrl = "http://localhost:62018/api/Account/SignupPost";
  const Registration = (e) => {  
    e.preventDefault();  
    debugger;  
    const data1 = {FullName:data.FullName, mobile_no:data.mobile_no, email:data.Email, username:data.username, password:data.password, confirm_password:data.confirm_password };  
    axios.post(apiUrl, data1)  
      .then((result) => {  
        debugger;  
        console.log(result.data);  
        if (result.data.Status === 'Invalid')  
          alert('Invalid User');  
        else  
          navigate('/Login/Login1')  
      })  
  } 


  const onChange = (e) => {  
    e.persist();  
    debugger;  
    setdata({ ...data, [e.target.name]: e.target.value });  
    
  }
  


  
  const [values, setValues] = useState({
    fullname: "",
    mobile_number:"",
    email: "",
    username: "",
    password: "",
    confirm_password: "",
    
   
  });
  
  const inputs = [
    {
      id: 1,
      name: "FullName",
      type: "text",
      placeholder: "Enter your  Name",
      errorMessage:
      "Username should be 3-16 characters and shouldn't include any special character!",
      label: " Name",
     
      },
    {
      id: 2,
      type:"tel",
      maxlength:"10",
      minlength:"9",
      name:"mobile_number",      
      placeholder: "Enter your Mobile",
      errorMessage: "It should be a valid Mobile No Only{10} !",
      label: "Mobile_Number",
      required: true,
      pattern:"[1-9]{1}[0-9]{9}"
    },
    {
      id: 3,
      name: "Email",
      type: "email",
      placeholder: "Enter your Email",
      errorMessage: "It should be a valid email address!",
      label: "Email",
      required: true,
    },
    {
      id: 4,
      name: "username",
      type: "text",
      placeholder: "Username",
      errorMessage: "Username should be 3-16 characters and shouldn't include any special character!",
      label: "Username",
      pattern: `^[A-Za-z0-9]{3,16}$`,
      required: true,
    },
    {
      id: 5,
      name: "password",
      type: "password",
      placeholder: "Password",
      errorMessage:
        "Password should be 8-20 characters and include at least 1 letter, 1 number and 1 special character!",
      label: "Password",
      pattern: `^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$`,
      required: true,
    },
    {
      id: 6,
      name: "confirm_password",
      type: "password",
      placeholder: "Confirm_Password",
      errorMessage:
        "Password should be 8-20 characters and include at least 1 letter, 1 number and 1 special character!",
      label: "Confirm_Password",
      pattern: `^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$`,
      required: true,
    },
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  

  return (

     
      <form className={style.form} onSubmit={Registration}>
        <h2 className={style.heading}>Create an Account</h2>
         <div className={style.form_grid}>

     
        {inputs.map((input) => (
          <FormInput
            key={input.id}
            {...input}
            
            value={data.name}
            onChange={onChange}
          />
        ))}
         </div>
               <div className={style.btn_container}>
          <button type="submit" className='btn btn-success'>Register</button>  Already have an account? <a href="http://localhost:3000/Login/Login1">Login Now</a>  
          </div>
      </form>

     
     
  );
};

export default Form;